package sample;

public class UserRequirements {
    int RequiredSeats;
    String Arrival;
    String Departure;

    public UserRequirements(int requiredSeats, String arrival, String departure) {
        RequiredSeats = requiredSeats;
        Arrival = arrival;
        Departure = departure;
    }

    public int getRequiredSeats() {
        return RequiredSeats;
    }

    public void setRequiredSeats(int requiredSeats) {
        RequiredSeats = requiredSeats;
    }

    public String getArrival() {
        return Arrival;
    }

    public void setArrival(String arrival) {
        Arrival = arrival;
    }

    public String getDeparture() {
        return Departure;
    }

    public void setDeparture(String departure) {
        Departure = departure;
    }
}
