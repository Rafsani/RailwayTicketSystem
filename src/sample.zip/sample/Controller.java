package sample;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class Controller {
    //private static final String Output_file_name = "User.txt";
    private static final String Filename="User.txt";


    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button signUpButton;

    @FXML
    private Button LoginButton;

    @FXML
    private PasswordField passwordTxt;

    @FXML
    private TextField NameTxt;
    @FXML
    private Label msgTxt;
    public static String Name,pass;

    public static List <User> users = new ArrayList(); //eita amar

    @FXML
    void loginPress(ActionEvent event) throws IOException
    {

        int i;


        try {
            String line;
            BufferedReader br = new BufferedReader(new FileReader(Filename));
                while (true) {
                    line = br.readLine();
                    String[] temp = line.split(",");
                    users.add(new User(temp[0], temp[1]));
                    if (line == null) break;
                }
                br.close();

        }
        catch (Exception e)
        {
            System.out.println("Train not found");
        }


        for(i=0; i<users.size(); i++)
        {
            if(users.get(i).getUser_name().equals(NameTxt.getText()) && users.get(i).getPassword().equals(passwordTxt.getText()))
            {
               // msgTxt.setText("Login success");
                System.out.println("Login Success");

                break;
            }

        }

        if(i == users.size())
        {
            msgTxt.setText("Either The Password or UserName is Incorrect");
        }
        else {
            Name = users.get(i).getUser_name();
            pass = users.get(i).getPassword();
            SceneChanger s =new SceneChanger();
            s.setSceneWithValue(event, "MyAccountPage.fxml",1030,574);
        }


        for(User a : users)
        {
            System.out.println(a);
        }
       // System.out.println(Name);
    }



    @FXML
    void signUpPressed(ActionEvent event) throws Exception{
        SceneChanger s =new SceneChanger();
        s.setScene(event, "SignUp.fxml",600,390);
    }

    @FXML
    void initialize() {
        assert signUpButton != null : "fx:id=\"signUpButton\" was not injected: check your FXML file 'finalLoginPage.fxml'.";
        assert LoginButton != null : "fx:id=\"LoginButton\" was not injected: check your FXML file 'finalLoginPage.fxml'.";
        assert passwordTxt != null : "fx:id=\"passwordTxt\" was not injected: check your FXML file 'finalLoginPage.fxml'.";
        assert NameTxt != null : "fx:id=\"NameTxt\" was not injected: check your FXML file 'finalLoginPage.fxml'.";
    }
}
