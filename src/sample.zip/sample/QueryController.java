package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class QueryController {

    @FXML
    private TextField DepartureTxt;

    @FXML
    private TextField ArrivalTxt;

    @FXML
    private TextField DepartureTimeTxt;

    @FXML
    private TextField DepartureDateTxt;

    @FXML
    private TextField QuantityTxt;

    @FXML
    private TextField ClassTxt;

    @FXML
    private Button SearchButton;

    @FXML
    private Button AboutButton;

    @FXML
    private Button GoBackButton;


    @FXML
    void AboutPress(ActionEvent event)throws IOException {
        // Takes You to Help Page

        SceneChanger s =new SceneChanger();
        s.setScene(event, "HelpPage.fxml",1030,574);
    }

    private static final String Filename1="TrainInfo";
    public static List<Train> trains = new ArrayList();
    public static List<Train> SearchTrains = new ArrayList();
    @FXML
    void SearchPress(ActionEvent event) throws IOException {
        //Opening the file
        int i;
        int[] search;
        int searchIdx=0;
        try {
            String line;
            BufferedReader br1 = new BufferedReader(new FileReader("TrainInfo.txt"));

                while (true) {

                    line = br1.readLine();
                    if (line == null) break;
                    System.out.println(line);
                  String[] temp = line.split(",");
                    trains.add(new Train(temp[0],temp[1],temp[2],temp[3],temp[4],temp[5],temp[6],Integer.parseInt(temp[7]),Integer.parseInt(temp[8]),Integer.parseInt(temp[9]),temp[10]));


                }
                br1.close();

                System.out.println(line);
            for( i=0;i<trains.size();i++)
            {
                if(trains.get(i).getDepartureStation().equalsIgnoreCase(DepartureTxt.getText()) && trains.get(i).getArrivalStation().equalsIgnoreCase(ArrivalTxt.getText()) )
                {
                    System.out.println(i);
                    System.out.println("Search Successful");
                    SearchTrains.add(trains.get(i));
                }
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        //Search


        //Going to Feedback page
        for(Train a : trains)
        {
            System.out.println(a);
        }
        SceneChanger s =new SceneChanger();
        s.setScene(event, "feedbackPage.fxml",1030,574);

        System.out.println(trains.size());

    }

    @FXML
    void GoBackPress(ActionEvent event) throws IOException{
        SceneChanger s =new SceneChanger();
        s.setScene(event, "MyAccountPage.fxml",1030,574);
    }

    @FXML
    void initialize() {
        assert AboutButton != null : "fx:id=\"AboutButton\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
        assert SearchButton != null : "fx:id=\"SearchButton\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
        assert GoBackButton != null : "fx:id=\"GoBackButton\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
        assert DepartureTxt != null : "fx:id=\"DepartureTxt\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
        assert ArrivalTxt != null : "fx:id=\"ArrivalTxt\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
        assert QuantityTxt != null : "fx:id=\"QuantityTxt\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
        assert DepartureTimeTxt != null : "fx:id=\"DepartureTimeTxt\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
        assert DepartureDateTxt != null : "fx:id=\"DepartureDateTxt\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
        assert ClassTxt != null : "fx:id=\"ClassTxt\" was not injected: check your FXML file 'UserQueryPage.fxml'.";
    }

}
