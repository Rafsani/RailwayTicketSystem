package sample;

public class SeatID {
    int Row;
    int Col;

    public SeatID(int row, int col) {
        Row = row;
        Col = col;
    }

    public int getRow() {
        return Row;
    }

    public void setRow(int row) {
        Row = row;
    }

    public int getCol() {
        return Col;
    }

    public void setCol(int col) {
        Col = col;
    }
}
