package sample;

public class User {
    private String User_name;
    private String Password;
    public User(String N, String P){
        User_name = N;
        Password = P;
    }

    public String getUser_name() {
        return User_name;
    }

    public void setUser_name(String user_name) {
        User_name = user_name;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String str(){
        String s;
        s = User_name + "," + Password;
        return s;
    }

    @Override
    public String toString() {
        return "User{" +
                "User_name='" + User_name + '\'' +
                ", Password='" + Password + '\'' +
                '}';
    }
}
