package sample;

public class NewTrainClass {

}
