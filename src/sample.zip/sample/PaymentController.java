package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;

public class PaymentController {

    @FXML
    private Button BookingButton;

    @FXML
    private Button HistoryButton;

    @FXML
    private Button AboutButton;

    @FXML
    private Button ExitButton;

    @FXML
    private Button SettingsButton;

    @FXML
    private Button bKashButton;

    @FXML
    private Button PaydeliveryButton;

    @FXML
    void AboutPress(ActionEvent event) {

    }

    @FXML
    void BookingPress(ActionEvent event) {

    }

    @FXML
    void DeliveryPress(ActionEvent event) {

    }

    @FXML
    void ExitPress(ActionEvent event) {

    }

    @FXML
    void HistoryPress(ActionEvent event) {

    }

    @FXML
    void SettingsPress(ActionEvent event) {

    }

    @FXML
    void bKashPress(ActionEvent event) {

    }

    @FXML
    void initialize() {
        assert BookingButton != null : "fx:id=\"BookingButton\" was not injected: check your FXML file 'Page.fxml'.";
        assert HistoryButton != null : "fx:id=\"HistoryButton\" was not injected: check your FXML file 'Page.fxml'.";
        assert AboutButton != null : "fx:id=\"AboutButton\" was not injected: check your FXML file 'Page.fxml'.";
        assert ExitButton != null : "fx:id=\"ExitButton\" was not injected: check your FXML file 'Page.fxml'.";
        assert SettingsButton != null : "fx:id=\"SettingsButton\" was not injected: check your FXML file 'Page.fxml'.";
        assert bKashButton != null : "fx:id=\"bKashButton\" was not injected: check your FXML file 'Page.fxml'.";
        assert PaydeliveryButton != null : "fx:id=\"PaydeliveryButton\" was not injected: check your FXML file 'Page.fxml'.";

    }


}
