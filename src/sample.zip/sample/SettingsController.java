package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;


public class SettingsController extends MenuController {


    @FXML
    private Button DoneButton;



    @FXML
    private TextField PrevName;

    @FXML
    private TextField PrevPassword;

    @FXML
    private TextField NewName;

    @FXML
    private TextField NewPassword;

    @FXML
    private Label msgTxt;



    //static List<User> users = new ArrayList();
    private static final String Filename="User.txt";
    @FXML
    void DonePress(ActionEvent event) {

        int i;


        try {
            String line;
            BufferedReader br = new BufferedReader(new FileReader(Filename));
            while (true) {
                line = br.readLine();
                while (true) {
                    line = br.readLine();
                    String[] temp = line.split(",");
                    Controller.users.add(new User(temp[0], temp[1]));
                    if (line == null) break;
                }
                br.close();
            }
        }
        catch (Exception e)
        {

        }


        for(i=0; i<Controller.users.size(); i++)
        {
            if(Controller.users.get(i).getUser_name().equals(PrevName.getText()) && Controller.users.get(i).getPassword().equals(PrevPassword.getText()))
            {
                // msgTxt.setText("Login success");
                System.out.println("Found");
                break;
            }

        }
        if(i == Controller.users.size())
        {
            msgTxt.setText("Sorry, Couldn't Find You.");
        }
        else{
            //Nothing is being Erased here, Need to handle Match Found, Need to Handle Null field

            Controller.users.get(i).setUser_name(NewName.getText());
            Controller.users.get(i).setPassword(NewPassword.getText());
            User user = new User(NewName.getText(),NewPassword.getText());
            try {
                FileWriter fw = new FileWriter(Filename,true); //true adds without re-writing
                while (true) {
                    fw.write("\n");
                    fw.write(user.str());
                    fw.close();
                }
            }
            catch (Exception e)
            {

            }
            msgTxt.setText("Done");
        }


    }

    @FXML
    void initialize() {
        super.initialize();
        assert DoneButton != null : "fx:id=\"DoneButton\" was not injected: check your FXML file 'Settings.fxml'.";
        assert PrevName != null : "fx:id=\"PrevName\" was not injected: check your FXML file 'SettingsPage.fxml'.";
        assert PrevPassword != null : "fx:id=\"PrevPassword\" was not injected: check your FXML file 'SettingsPage.fxml'.";
        assert NewPassword != null : "fx:id=\"NewPassword\" was not injected: check your FXML file 'SettingsPage.fxml'.";
        assert NewName != null : "fx:id=\"NewName\" was not injected: check your FXML file 'SettingsPage.fxml'.";
        assert msgTxt != null : "fx:id=\"msgTxt\" was not injected: check your FXML file 'SettingsPage.fxml'.";

    }

}

