package sample;

import java.net.URL;
import java.util.Collection;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import javax.swing.*;

import static sample.QueryController.SearchTrains;
import static sample.QueryController.trains;

public class FeedBackController {
   @FXML
   private Button goBack;

   @FXML
   private Button selectTrain;


   @FXML
   private Label ResultCounterTxt;

   @FXML
   private TableView<Train> trainTableView;

   @FXML
   private TableColumn<Train, String> trainNameColumn = new TableColumn<>("TrainName");


   @FXML
   private TableColumn<Train, String> departureTxtColumn;

   @FXML
   private TableColumn<Train, String > arrivalTxtColumn;

   @FXML
   private TableColumn<Train,String > timeTxtColumn;

   @FXML
   private TableColumn<Train, String > ratingTxtColumn;
   @FXML
   void goBackpressed(ActionEvent event) throws Exception
   {
      SceneChanger s = new SceneChanger();
      s.setScene(event,"UserQueryPage.fxml",1030,574);
      SearchTrains.removeAll(trains);
   }

 //  private TableView<Train> taview = trainTableView;
   @FXML
   void selectTrainPressed(ActionEvent event) {
      Train train = trainTableView.getSelectionModel().getSelectedItem();
      System.out.println(train);
   }


   @FXML
   void initialize() {
      assert ResultCounterTxt != null : "fx:id=\"ResultCounterTxt\" was not injected: check your FXML file 'feedbackPage.fxml'.";
      assert trainTableView != null : "fx:id=\"trainTableView\" was not injected: check your FXML file 'feedbackPage.fxml'.";
      assert trainNameColumn != null : "fx:id=\"trainNameColumn\" was not injected: check your FXML file 'feedbackPage.fxml'.";
      assert departureTxtColumn != null : "fx:id=\"departureTxtColumn\" was not injected: check your FXML file 'feedbackPage.fxml'.";
      assert arrivalTxtColumn != null : "fx:id=\"arrivalTxtColumn\" was not injected: check your FXML file 'feedbackPage.fxml'.";
      assert timeTxtColumn != null : "fx:id=\"timeTxtColumn\" was not injected: check your FXML file 'feedbackPage.fxml'.";
      assert ratingTxtColumn != null : "fx:id=\"ratingTxtColumn\" was not injected: check your FXML file 'feedbackPage.fxml'.";
      trainNameColumn.setCellValueFactory(new PropertyValueFactory<> ("Train_Name"));
      departureTxtColumn.setCellValueFactory(new PropertyValueFactory<> ("DepartureStation"));
      arrivalTxtColumn.setCellValueFactory(new PropertyValueFactory<> ("ArrivalStation"));
      timeTxtColumn.setCellValueFactory(new PropertyValueFactory<> ("ArrivalTime"));
      ratingTxtColumn.setCellValueFactory(new PropertyValueFactory<> ("Rating"));
      ObservableList<Train> os = FXCollections.observableArrayList(SearchTrains);

      trainTableView.setItems(os);
      ResultCounterTxt.setText(String.valueOf(SearchTrains.size()));
   }
}
